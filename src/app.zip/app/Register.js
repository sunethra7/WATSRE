"use strict";
var Register = (function () {
    function Register(s, n, a) {
        this.arrow = '';
        this.name = s;
        this.value = n;
        this.arrow = a;
    }
    return Register;
}());
exports.Register = Register;
//# sourceMappingURL=Register.js.map