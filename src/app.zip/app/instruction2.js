"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var Register_1 = require("./Register");
var Instruction2 = (function () {
    function Instruction2() {
        this.remainderToDisplay = '';
        this.arrow = '';
        this.outputValue = '0';
        this.valueToAdd2 = '';
        this.showAdd = false;
        this.showSub = false;
        this.showMul = false;
        this.showDiv = false;
        this.showMov = false;
        this.showInc = false;
        this.showDec = false;
        this.showAnd = false;
        this.showOR = false;
        this.showXOR = false;
        this.showNOT = false;
        this.showPush = false;
        this.showPop = false;
        this.showJmp = false;
        this.showCmp = false;
        this.showJz = false;
        this.showJnz = false;
        this.addNumberBoolean = false;
        this.addRegisterBoolean = false;
        this.subNumberBoolean = false;
        this.subRegisterBoolean = false;
        this.mulNumberBoolean = false;
        this.mulRegisterBoolean = false;
        this.mulRegisterTwoBoolean = false;
        this.divNumberBoolean = false;
        this.divRegisterBoolean = false;
        this.movNumberBoolean = false;
        this.movRegisterBoolean = false;
        this.incBoolean = false;
        this.decBoolean = false;
        this.cmpNumberBoolean = false;
        this.cmpRegisterBoolean = false;
        this.jmpNumberBoolean = false;
        this.jmpRegisterBoolean = false;
        this.jmpZeroRegisterBoolean = false;
        this.jmpZeroNumberBoolean = false;
        this.jmpIfNotZeroRegisterBoolean = false;
        this.jmpIfNotZeroNumberBoolean = false;
        this.selectedRegister1 = '';
        this.selectedRegister2 = '';
        this.selectedRegister3 = '';
        this.selectedRegister4 = '';
        this.selectedRegister5 = '';
        this.register = [
            new Register_1.Register('RAX', '0000000000000005', ''),
            new Register_1.Register('RBX', '0000000000000006', ''),
            new Register_1.Register('RCX', '0000000000000015', ''),
            new Register_1.Register('RDX', '0000000000000012', ''),
            new Register_1.Register('RBP', '00000000000000a1', ''),
            new Register_1.Register('RSP', '0000000000FEF1B0', ''),
            new Register_1.Register('RSI', '000000000000002d', ''),
            new Register_1.Register('RDI', '000000000000003a', ''),
            new Register_1.Register('RIP', '000000000000009b', ''),
            new Register_1.Register('R8', '0000000000000000', ''),
            new Register_1.Register('R9', '0000000000000000', ''),
            new Register_1.Register('R10', '0000000000000000', ''),
            new Register_1.Register('R11', '0000000000000000', ''),
            new Register_1.Register('R12', '0000000000000000', ''),
            new Register_1.Register('R13', '0000000000000000', ''),
            new Register_1.Register('R14', '0000000000000000', ''),
            new Register_1.Register('R15', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF150', '0000000000000010', ''),
            new Register_1.Register('0000000000FEF158', '000000000000000a', ''),
            new Register_1.Register('0000000000FEF160', '00000000000000c5', ''),
            new Register_1.Register('0000000000FEF168', '00000000000000a3', ''),
            new Register_1.Register('0000000000FEF170', '0000000000000180', ''),
            new Register_1.Register('0000000000FEF178', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF180', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF188', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF190', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF198', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF1A0', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF1A8', '0000000000000000', ''),
            new Register_1.Register('0000000000FEF1B0', '0000000000000008', ''),
            new Register_1.Register('0000000000FEF1C0', '0000000000000001', ''),
            new Register_1.Register('0000000000FEF1C8', '0000000000000002', ''),
            new Register_1.Register('0000000000FEF1D0', '0000000000000003', ''),
            new Register_1.Register('0000000000FEF1D8', '0000000000000004', ''),
            new Register_1.Register('L1', '', ''),
            new Register_1.Register('L2', '', ''),
            new Register_1.Register('L3', '', ''),
            new Register_1.Register('L4', '', ''),
            new Register_1.Register('L5', '', ''),
            new Register_1.Register('L6', '', ''),
            new Register_1.Register('L7', '', '')
        ];
        this.memoryList = ['0000000000FEF150', '0000.000000FEF158', '0000000000FEF1A0', '0000000000FEF1A8', '0000000000FEF1B0',
            '0000000000FEF1C0', '0000000000FEF1C8', '0000000000FEF1D0', '0000000000FEF1D8'];
        //   public subRegister(): void {
        //   let temp1: Register = new Register('', '0');
        //   let temp2: Register = new Register('', '0');
        //   for (let r of this.register) {
        //     if (this.selectedRegister2 == r.name) {
        //       temp1 = r;
        //     }
        //   }
        //   for (let r of this.register) {
        //     if (this.selectedRegister3 == r.name) {
        //       temp2 = r;
        //     }
        //   }
        //   temp1.value = temp1.value - temp2.value;
        //   this.outputValue = temp1.value;
        // }
    }
    Instruction2.prototype.checkIfRegister = function (r1) {
        if (r1.name == 'RAX' || r1.name == 'RBX' || r1.name == 'RCX' || r1.name == 'RDX' || r1.name == 'RBP' || r1.name == 'RSP' || r1.name == 'RDI' ||
            r1.name == 'RSI' || r1.name == 'RIP' || r1.name == 'R8' || r1.name == 'R9' || r1.name == 'R10' || r1.name == 'R11' ||
            r1.name == 'R12' || r1.name == 'R13' || r1.name == 'R14' || r1.name == 'R15') {
            return true;
        }
        else {
            return false;
        }
    };
    Instruction2.prototype.checkIfLabel = function (r1) {
        if (r1.name == 'L1' || r1.name == 'L2' || r1.name == 'L3' || r1.name == 'L4' || r1.name == 'L5' || r1.name == 'L6' || r1.name == 'L7') {
            return true;
        }
        else {
            return false;
        }
    };
    Instruction2.prototype.checkIfMemory = function (r1) {
        if (r1.name == '0000000000FEF150' || r1.name == '0000000000FEF158' || r1.name == '0000000000FEF160' ||
            r1.name == '0000000000FEF168' || r1.name == '0000000000FEF170' || r1.name == '0000000000FEF178' ||
            r1.name == '0000000000FEF180' || r1.name == '0000000000FEF188' || r1.name == '0000000000FEF190' ||
            r1.name == '0000000000FEF198' || r1.name == '0000000000FEF1A0' || r1.name == '0000000000FEF1A8' ||
            r1.name == '0000000000FEF1B0' || r1.name == '0000000000FEF1B8' || r1.name == '0000000000FEF1C0' ||
            r1.name == '0000000000FEF1C8' || r1.name == '0000000000FEF1D0' || r1.name == '0000000000FEF1D8') {
            return true;
        }
        else {
            return false;
        }
    };
    Instruction2.prototype.ngOnInit = function () {
        var num1 = '100';
        var num2 = '';
        var num3 = parseInt(num1, 16);
        console.log(num3);
        var num4 = '6000';
        console.log((parseInt(num4, 16) / parseInt(num1, 16)).toString(16));
        console.log('************************************');
        //this.pushRegister();
    };
    Instruction2.prototype.resetParameters = function () {
        this.showAdd = false;
        this.showSub = false;
        this.showMul = false;
        this.showDiv = false;
        this.showInc = false;
        this.showDec = false;
        this.showMov = false;
        this.showPush = false;
        this.showPop = false;
        this.showAnd = false;
        this.showOR = false;
        this.showXOR = false;
        this.showNOT = false;
        this.showJmp = false;
        this.showCmp = false;
        this.showJz = false;
        this.showJnz = false;
    };
    Instruction2.prototype.addNumber = function () {
        this.addRegisterBoolean = false;
        this.addNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 + temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = "fa fa-arrow-right fa-3x";
                console.log(r);
                this.outputValue = r.value;
            }
        }
    };
    Instruction2.prototype.addRegister = function () {
        console.log("r");
        this.addRegisterBoolean = true;
        this.addNumberBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        var r;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r_1 = _a[_i];
            r_1.arrow = '';
            if (this.selectedRegister2 == r_1.name) {
                temp1 = r_1;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r_2 = _c[_b];
            if (this.selectedRegister3 == r_2.name) {
                temp2 = r_2;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 + temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = "fa fa-arrow-right";
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.subNumber = function () {
        this.subRegisterBoolean = false;
        this.subNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                this.outputValue = r.value;
            }
        }
    };
    Instruction2.prototype.subRegister = function () {
        this.subRegisterBoolean = true;
        this.subNumberBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 - temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.mulNumber = function () {
        this.mulRegisterBoolean = false;
        this.mulNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 * temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                this.outputValue = r.value;
            }
        }
    };
    Instruction2.prototype.mulRegister = function () {
        this.mulRegisterBoolean = true;
        this.mulNumberBoolean = false;
        this.mulRegisterTwoBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 * temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.mulRegister2 = function () {
        this.mulRegisterTwoBoolean = true;
        this.mulNumberBoolean = false;
        this.mulRegisterBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        var temp6 = parseInt(this.valueToAdd2, 16);
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister4 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister5 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 * temp4 * temp6;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.divNumber = function () {
        this.divNumberBoolean = true;
        this.divRegisterBoolean = false;
        var temp1 = 0;
        var temp2 = 0;
        var quotient = 0;
        var remainder = 0;
        var remainderString = '';
        var valueToStore = '';
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                temp1 = parseInt(r.value, 16);
                temp2 = parseInt(this.valueToAdd, 16);
                quotient = Math.floor(temp1 / temp2);
                remainder = temp1 % temp2;
                console.log(remainderString);
                temp1 = quotient;
                //append zeros so that length becomes 16
                console.log(temp1);
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                for (var i = 0; i < (16 - l); i++) {
                    remainderString = remainderString + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (r.name == 'RAX') {
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
            if (r.name == 'RDX') {
                remainderString = remainderString + remainder.toString(16);
                console.log(remainderString);
                r.value = remainderString;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.divRegister = function () {
        this.divNumberBoolean = false;
        this.divRegisterBoolean = true;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        var quotient = 0;
        var remainder = 0;
        var remainderString = '';
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        quotient = Math.floor(temp3 / temp4);
        remainder = temp3 % temp4;
        //let temp6 = temp3 % temp4;
        temp3 = quotient;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i_1 = 0; i_1 < (16 - l); i_1++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        for (var i = 0; i < (16 - l); i++) {
            remainderString = remainderString + '0';
        }
        for (var _d = 0, _e = this.register; _d < _e.length; _d++) {
            var r = _e[_d];
            if (r.name == 'RAX') {
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                this.outputValue = r.value;
            }
        }
        for (var _f = 0, _g = this.register; _f < _g.length; _f++) {
            var r = _g[_f];
            if (r.name == 'RDX') {
                remainderString = remainderString + remainder.toString(16);
                r.value = remainderString;
                r.arrow = 'fa fa-arrow-right fa-3x';
                this.remainderToDisplay = r.value;
            }
        }
        //this.outputValue = temp1.value;
    };
    Instruction2.prototype.movNumber = function () {
        this.movNumberBoolean = true;
        this.movRegisterBoolean = false;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                console.log(r.arrow);
            }
        }
    };
    Instruction2.prototype.movRegister = function () {
        this.movNumberBoolean = false;
        this.movRegisterBoolean = true;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.incNumber = function () {
        this.incBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                // let temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 + 1;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                console.log(r.arrow);
            }
        }
    };
    Instruction2.prototype.decNumber = function () {
        this.decBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                // let temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - 1;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
                console.log(r.arrow);
            }
        }
    };
    Instruction2.prototype.pushRegister = function () {
        var tempRSPValue;
        var temp;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var sRegister = _a[_i];
            sRegister.arrow = '';
            if (this.selectedRegister1 == sRegister.name) {
                temp = sRegister.value;
            }
        }
        for (var r = 0; r < this.register.length; r++) {
            if (this.register[r].name == 'RSP') {
                tempRSPValue = this.register[r].value;
                console.log(tempRSPValue);
            }
        }
        for (var r = 0; r < this.register.length; r++) {
            if (this.register[r].name == tempRSPValue) {
                for (var i = this.register.length - 1; i > r; i--) {
                    this.register[i].value = this.register[i - 1].value;
                }
                this.register[r].value = temp;
                this.register[r].arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.popRegister = function () {
        var tempRSPRegister = new Register_1.Register('', '0', '');
        var tempRSPValue;
        var temp;
        for (var r = 0; r < this.register.length; r++) {
            this.register[r].arrow = '';
            if (this.register[r].name == 'RSP') {
                tempRSPValue = this.register[r].value;
                console.log(tempRSPValue);
                tempRSPRegister = this.register[r];
                tempRSPRegister.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
        for (var r = 0; r < this.register.length; r++) {
            if (this.register[r].name == tempRSPValue) {
                tempRSPRegister.value = this.register[r + 1].name;
                for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
                    var s = _a[_i];
                    if (this.selectedRegister1 == s.name) {
                        s.value = this.register[r].value;
                        s.arrow = 'fa fa-arrow-right fa-3x';
                    }
                }
            }
        }
    };
    //    this.memoryList[j] = this.memoryList[j-1];
    //   }
    // -----------------------------------------------------------
    //   for(var i=0;i<this.memoryList.length; i++){
    //     console.log(this.memoryList.length);
    //     if(this.memoryList[i]!=tempRSPValue){
    //       continue; 
    //     }
    //     if(this.memoryList[i] == tempRSPValue){
    //       console.log('Inside if loop');
    //       this.pushRegister1(i);
    //     }
    //   }
    // }
    // public pushRegister1(i: number){
    //   console.log('inside pushRegister1 method');
    //   //let memoryIndexToInsert: number =i;
    //   for(let j =this.memoryList.length-1;j>i;j--){
    //    this.memoryList[j] = this.memoryList[j-1];
    //   }
    //   this.memoryList[i] = '5';
    //   console.log(this.memoryList[i]);
    // }
    Instruction2.prototype.andNumber = function () {
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 & temp2;
                console.log(temp1);
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.andRegister = function () {
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 & temp4;
        console.log(temp3);
        //temp3 = temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.orNumber = function () {
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 | temp2;
                console.log(temp1);
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.orRegister = function () {
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 | temp4;
        console.log(temp3);
        //temp3 = temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.xorNumber = function () {
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 ^ temp2;
                console.log(temp1);
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.xorRegister = function () {
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 ^ temp4;
        console.log(temp3);
        //temp3 = temp4;
        var temp5 = temp3.toString(16);
        var l = temp5.length;
        var valueToStore = '';
        for (var i = 0; i < (16 - l); i++) {
            valueToStore = valueToStore + '0';
        }
        valueToStore += temp5;
        temp1.value = valueToStore;
        temp1.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp1.value;
    };
    Instruction2.prototype.notNumber = function () {
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                //let temp2 = parseInt(this.valueToAdd, 16);
                temp1 = ~temp1;
                console.log(temp1);
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                var l = temp3.length;
                var valueToStore = '';
                for (var i = 0; i < (16 - l); i++) {
                    valueToStore = valueToStore + '0';
                }
                valueToStore = valueToStore + temp3;
                console.log(valueToStore);
                r.value = valueToStore;
                r.arrow = 'fa fa-arrow-right fa-3x';
            }
        }
    };
    Instruction2.prototype.jmpLabel = function () {
        this.jmpRegisterBoolean = false;
        this.jmpNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                r.arrow = 'fa fa-arrow-right fa-3x';
                console.log(r.arrow);
            }
        }
    };
    Instruction2.prototype.cmpNumber = function () {
        this.cmpRegisterBoolean = false;
        this.cmpNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                // let l = temp3.length;
                //  let valueToStore: string = '';
                // for (var i = 0; i < (16 - l); i++) {
                //   valueToStore = valueToStore + '0';
                // }
                // valueToStore = valueToStore + temp3;
                // console.log(valueToStore);
                // r.value = temp3;
                // r.arrow = 'fa fa-arrow-right fa-3x';
                this.outputValue = temp3;
            }
        }
    };
    Instruction2.prototype.cmpRegister = function () {
        this.cmpRegisterBoolean = true;
        this.cmpNumberBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 - temp4;
        var temp5 = temp3.toString(16);
        // let l = temp5.length;
        // let valueToStore: string = '';
        // for (let i = 0; i < (16 - l); i++) {
        //   valueToStore = valueToStore + '0';
        // }
        // valueToStore += temp5;
        //temp1.value = valueToStore;
        // temp1.arrow = 'fa fa-arrow-right fa-3x'
        this.outputValue = temp5;
    };
    Instruction2.prototype.jmpNumber = function () {
        this.jmpRegisterBoolean = false;
        this.jmpNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - temp2;
                //append zeros so that length becomes 16
                var temp3 = temp1.toString(16);
                // let l = temp3.length;
                //  let valueToStore: string = '';
                // for (var i = 0; i < (16 - l); i++) {
                //   valueToStore = valueToStore + '0';
                // }
                // valueToStore = valueToStore + temp3;
                // console.log(valueToStore);
                // r.value = temp3;
                // r.arrow = 'fa fa-arrow-right fa-3x';
                this.outputValue = temp3;
            }
        }
    };
    Instruction2.prototype.jmpZeroNumber = function () {
        this.jmpZeroRegisterBoolean = false;
        this.jmpZeroNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - temp2;
                var temp3 = temp1.toString(16);
                this.outputValue = temp3;
            }
        }
        console.log(this.outputValue);
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.outputValue == '0') {
                if (this.selectedRegister5 == r.name) {
                    r.arrow = 'fa fa-arrow-right fa-3x';
                    console.log("true");
                    console.log(r.arrow);
                }
            }
            else {
                r.arrow = '';
                console.log("False");
            }
        }
    };
    Instruction2.prototype.jmpZeroRegister = function () {
        this.jmpZeroRegisterBoolean = true;
        this.jmpZeroNumberBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 - temp4;
        var temp5 = temp3.toString(16);
        this.outputValue = temp5;
        console.log(this.outputValue);
        for (var _d = 0, _e = this.register; _d < _e.length; _d++) {
            var r = _e[_d];
            if (this.outputValue == '0') {
                if (this.selectedRegister4 == r.name) {
                    r.arrow = 'fa fa-arrow-right fa-3x';
                    console.log("true");
                    console.log(r.arrow);
                }
            }
            else {
                r.arrow = '';
                console.log("False");
            }
        }
    };
    Instruction2.prototype.jmpIfNotZeroNumber = function () {
        this.jmpIfNotZeroRegisterBoolean = false;
        this.jmpIfNotZeroNumberBoolean = true;
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister1 == r.name) {
                var temp1 = parseInt(r.value, 16);
                var temp2 = parseInt(this.valueToAdd, 16);
                temp1 = temp1 - temp2;
                var temp3 = temp1.toString(16);
                this.outputValue = temp3;
            }
        }
        console.log(this.outputValue);
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.outputValue != '0') {
                if (this.selectedRegister5 == r.name) {
                    r.arrow = 'fa fa-arrow-right fa-3x';
                    console.log("false");
                    console.log(r.arrow);
                }
            }
            else {
                r.arrow = '';
                console.log("true");
            }
        }
    };
    Instruction2.prototype.jmpIfNotZeroRegister = function () {
        this.jmpIfNotZeroRegisterBoolean = true;
        this.jmpIfNotZeroNumberBoolean = false;
        var temp1 = new Register_1.Register('', '0', '');
        var temp2 = new Register_1.Register('', '0', '');
        for (var _i = 0, _a = this.register; _i < _a.length; _i++) {
            var r = _a[_i];
            r.arrow = '';
            if (this.selectedRegister2 == r.name) {
                temp1 = r;
            }
        }
        for (var _b = 0, _c = this.register; _b < _c.length; _b++) {
            var r = _c[_b];
            if (this.selectedRegister3 == r.name) {
                temp2 = r;
            }
        }
        var temp3 = parseInt(temp1.value, 16);
        var temp4 = parseInt(temp2.value, 16);
        temp3 = temp3 - temp4;
        var temp5 = temp3.toString(16);
        this.outputValue = temp5;
        console.log(this.outputValue);
        for (var _d = 0, _e = this.register; _d < _e.length; _d++) {
            var r = _e[_d];
            if (this.outputValue != '0') {
                if (this.selectedRegister4 == r.name) {
                    r.arrow = 'fa fa-arrow-right fa-3x';
                    console.log("false");
                    console.log(r.arrow);
                }
            }
            else {
                r.arrow = '';
                console.log("true");
            }
        }
    };
    Instruction2.prototype.showAddSection = function () {
        this.resetParameters();
        this.showAdd = true;
    };
    Instruction2.prototype.showSubSection = function () {
        this.resetParameters();
        this.showSub = true;
    };
    Instruction2.prototype.showMulSection = function () {
        this.resetParameters();
        this.showMul = true;
    };
    Instruction2.prototype.showDivSection = function () {
        this.resetParameters();
        this.showDiv = true;
    };
    Instruction2.prototype.showMovSection = function () {
        this.resetParameters();
        this.showMov = true;
    };
    Instruction2.prototype.showIncSection = function () {
        this.resetParameters();
        this.showInc = true;
    };
    Instruction2.prototype.showDecSection = function () {
        this.resetParameters();
        this.showDec = true;
    };
    Instruction2.prototype.showPushSection = function () {
        this.resetParameters();
        this.showPush = true;
    };
    Instruction2.prototype.showPopSection = function () {
        this.resetParameters();
        this.showPop = true;
    };
    Instruction2.prototype.showAndSection = function () {
        this.resetParameters();
        this.showAnd = true;
    };
    Instruction2.prototype.showORSection = function () {
        this.resetParameters();
        this.showOR = true;
    };
    Instruction2.prototype.showXORSection = function () {
        this.resetParameters();
        this.showXOR = true;
    };
    Instruction2.prototype.showNOTSection = function () {
        this.resetParameters();
        this.showNOT = true;
    };
    Instruction2.prototype.showJmpSection = function () {
        this.resetParameters();
        this.showJmp = true;
    };
    Instruction2.prototype.showCmpSection = function () {
        this.resetParameters();
        this.showCmp = true;
    };
    Instruction2.prototype.showJzSection = function () {
        this.resetParameters();
        this.showJz = true;
    };
    Instruction2.prototype.showJnzSection = function () {
        this.resetParameters();
        this.showJnz = true;
    };
    return Instruction2;
}());
Instruction2 = __decorate([
    core_1.Component({
        selector: 'my-instruction2',
        templateUrl: './instruction2.html',
        styleUrls: ['./app.component.scss'],
    })
], Instruction2);
exports.Instruction2 = Instruction2;
//# sourceMappingURL=instruction2.js.map