import { Component } from '@angular/core';
import { FormsModule, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'my-home',
  templateUrl: './home.html',
  styleUrls: ['./app.component.scss'],
})
export class Home {
}

