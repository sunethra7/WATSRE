import { Component } from '@angular/core';
import { FormsModule, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Register } from './Register';
@Component({
  selector: 'my-instruction2',
  templateUrl: './instruction2.html',
  styleUrls: ['./app.component.scss'],
})
export class Instruction2 {
  private remainderToDisplay: string = '';
  private arrow: string = '';
  private outputValue: string = '0';
  private valueToAdd: string;
  private valueToAdd2: string = '';
  private showAdd: boolean = false;
  private showSub: boolean = false;
  private showMul: boolean = false;
  private showDiv: boolean = false;
  private showMov: boolean = false;
  private showInc: boolean = false;
  private showDec: boolean = false;  
  private showAnd: boolean = false;
  private showOR: boolean = false;
  private showXOR: boolean = false;
  private showNOT: boolean = false;
  private showPush: boolean = false;
  private showPop : boolean = false;
  private showJmp : boolean = false;
  private showCmp : boolean = false;
  private showJz:boolean = false;
  private showJnz:boolean = false;
  private addNumberBoolean: boolean = false;
  private addRegisterBoolean: boolean = false;
  private subNumberBoolean: boolean = false;
  private subRegisterBoolean: boolean = false;
  private mulNumberBoolean: boolean = false;
  private mulRegisterBoolean: boolean = false;  
  private mulRegisterTwoBoolean: boolean = false;
  private divNumberBoolean: boolean = false;    
  private divRegisterBoolean: boolean =false;
  private movNumberBoolean: boolean = false;    
  private movRegisterBoolean: boolean =false;
  private incBoolean: boolean = false;
  private decBoolean: boolean = false;
  private cmpNumberBoolean: boolean = false;
  private cmpRegisterBoolean: boolean = false;
  private jmpNumberBoolean: boolean = false;
  private jmpRegisterBoolean: boolean = false;
  private jmpZeroRegisterBoolean = false;
  private jmpZeroNumberBoolean = false;
  private jmpIfNotZeroRegisterBoolean :boolean = false;
  private jmpIfNotZeroNumberBoolean :boolean = false;
  private selectedRegister1: string = '';
  private selectedRegister2: string = '';
  private selectedRegister3: string = '';
  private selectedRegister4: string = '';
  private selectedRegister5: string = '';
  private register: Register[] = [
    new Register('RAX', '0000000000000005', ''),
    new Register('RBX', '0000000000000006', ''),
    new Register('RCX', '0000000000000015', ''),
    new Register('RDX', '0000000000000012', ''),
    new Register('RBP', '00000000000000a1', ''),
    new Register('RSP', '0000000000FEF1B0', ''),
    new Register('RSI', '000000000000002d', ''),
    new Register('RDI', '000000000000003a', ''),
    new Register('RIP', '000000000000009b', ''),
    new Register('R8', '0000000000000000', ''),
    new Register('R9', '0000000000000000', ''),
    new Register('R10', '0000000000000000', ''),
    new Register('R11', '0000000000000000', ''),
    new Register('R12', '0000000000000000', ''),
    new Register('R13', '0000000000000000', ''),
    new Register('R14', '0000000000000000', ''),
    new Register('R15', '0000000000000000', ''),
    new Register('0000000000FEF150', '0000000000000010', ''),
    new Register('0000000000FEF158', '000000000000000a', ''),
    new Register('0000000000FEF160', '00000000000000c5', ''),
    new Register('0000000000FEF168', '00000000000000a3', ''),
    new Register('0000000000FEF170', '0000000000000180', ''),
    new Register('0000000000FEF178', '0000000000000000', ''),
    new Register('0000000000FEF180', '0000000000000000', ''),
    new Register('0000000000FEF188', '0000000000000000', ''),
    new Register('0000000000FEF190', '0000000000000000', ''),
    new Register('0000000000FEF198', '0000000000000000', ''),
    new Register('0000000000FEF1A0', '0000000000000000', ''),
    new Register('0000000000FEF1A8', '0000000000000000', ''),
    new Register('0000000000FEF1B0', '0000000000000008', ''),
    new Register('0000000000FEF1C0', '0000000000000001', ''),
    new Register('0000000000FEF1C8', '0000000000000002', ''),
    new Register('0000000000FEF1D0', '0000000000000003', ''),
    new Register('0000000000FEF1D8', '0000000000000004', ''),
    new Register('L1','', ''),
    new Register('L2','', ''),
    new Register('L3','', ''),
    new Register('L4','', ''),
    new Register('L5','', ''),
    new Register('L6','', ''),
    new Register('L7','', '')

  ];
  private memoryList: string[] = ['0000000000FEF150', '0000.000000FEF158', '0000000000FEF1A0', '0000000000FEF1A8', '0000000000FEF1B0'
    , '0000000000FEF1C0', '0000000000FEF1C8', '0000000000FEF1D0', '0000000000FEF1D8'];



  public checkIfRegister(r1: Register) {
    if (r1.name == 'RAX' || r1.name == 'RBX' || r1.name == 'RCX' || r1.name == 'RDX' || r1.name == 'RBP' || r1.name == 'RSP' || r1.name == 'RDI' ||
      r1.name == 'RSI' || r1.name == 'RIP' || r1.name == 'R8' || r1.name == 'R9' || r1.name == 'R10' || r1.name == 'R11' ||
      r1.name == 'R12' || r1.name == 'R13' || r1.name == 'R14' || r1.name == 'R15') {
      return true;
    } else {
      return false;
    }

  }

public checkIfLabel(r1: Register) {
    if (r1.name == 'L1' || r1.name == 'L2' || r1.name == 'L3'|| r1.name == 'L4' || r1.name == 'L5' || r1.name == 'L6' || r1.name == 'L7') {
      return true;
    } else {
      return false;
    }

  }


  public checkIfMemory(r1: Register) {
    if (r1.name == '0000000000FEF150' || r1.name == '0000000000FEF158' || r1.name == '0000000000FEF160' ||
      r1.name == '0000000000FEF168' || r1.name == '0000000000FEF170' || r1.name == '0000000000FEF178' ||
      r1.name == '0000000000FEF180' || r1.name == '0000000000FEF188' || r1.name == '0000000000FEF190' ||
      r1.name == '0000000000FEF198' || r1.name == '0000000000FEF1A0' || r1.name == '0000000000FEF1A8' ||
      r1.name == '0000000000FEF1B0' || r1.name == '0000000000FEF1B8' || r1.name == '0000000000FEF1C0' ||
      r1.name == '0000000000FEF1C8' || r1.name == '0000000000FEF1D0' || r1.name == '0000000000FEF1D8') {
      return true;
    } else {
      return false;
    }

  }

  ngOnInit() {
    let num1: string = '100';
    let num2: string = '';
    let num3: number = parseInt(num1, 16);
    console.log(num3);

    let num4: string = '6000';
    console.log((parseInt(num4, 16) / parseInt(num1, 16)).toString(16));
    console.log('************************************');
    //this.pushRegister();
  }

  public resetParameters() {
    this.showAdd = false;
    this.showSub = false;
    this.showMul = false;
    this.showDiv = false;   
    this.showInc = false;
    this.showDec = false;
    this.showMov = false;
    this.showPush = false;
    this.showPop = false;
    this.showAnd = false;
    this.showOR = false;
    this.showXOR = false;
    this.showNOT = false;
    this.showJmp = false;
    this.showCmp = false;
    this.showJz = false;
    this.showJnz = false;

  }

  public addNumber(): void {
    this.addRegisterBoolean =false;
    this.addNumberBoolean = true;
    
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 + temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = "fa fa-arrow-right fa-3x";
        console.log(r);
        this.outputValue = r.value;
      }
    }

  }

  public addRegister(): void {
    console.log("r" )
    this.addRegisterBoolean =true;
    this.addNumberBoolean = false;
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');
    let r;

    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;
      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 + temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = "fa fa-arrow-right";
    this.outputValue = temp1.value;
  }

  public subNumber(): void {
    this.subRegisterBoolean =false;
    this.subNumberBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = r.value;
      }
    }

  }

  public subRegister(): void {
    this.subRegisterBoolean =true;
    this.subNumberBoolean = false;
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 - temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x'
    this.outputValue = temp1.value;
  }

  public mulNumber(): void {
    
    this.mulRegisterBoolean =false;
    this.mulNumberBoolean = true;

    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 * temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = r.value;
      }
    }

  }

  public mulRegister(): void {
    this.mulRegisterBoolean =true;
    this.mulNumberBoolean = false;    
    this.mulRegisterTwoBoolean =false;
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 * temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x'
    this.outputValue = temp1.value;
  }

  public mulRegister2(): void {
    this.mulRegisterTwoBoolean =true;
    this.mulNumberBoolean = false;    
    this.mulRegisterBoolean =false;
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');
    let temp6 = parseInt(this.valueToAdd2, 16);

    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister4 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister5 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 * temp4 * temp6;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x'
    this.outputValue = temp1.value;
  }

  public divNumber(): void {
    this.divNumberBoolean = true;    
    this.divRegisterBoolean =false;
    let temp1 = 0;
    let temp2 = 0;
    let quotient: number = 0;
    let remainder = 0;
    let remainderString = '';
    let valueToStore: string = '';
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        temp1 = parseInt(r.value, 16);
        temp2 = parseInt(this.valueToAdd, 16);

        quotient = Math.floor(temp1 / temp2);
        remainder = temp1 % temp2;

        console.log(remainderString);
        temp1 = quotient;
        //append zeros so that length becomes 16
        console.log(temp1);

        let temp3 = temp1.toString(16);

        let l = temp3.length;

        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }

        for (var i = 0; i < (16 - l); i++) {
          remainderString = remainderString + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        //r.value = valueToStore;
        // r.arrow='fa fa-arrow-right fa-3x';
      }

    }
    for (let r of this.register) {
      if (r.name == 'RAX') {
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
      }
      if (r.name == 'RDX') {
        remainderString = remainderString + remainder.toString(16);
        console.log(remainderString);
        r.value = remainderString;
        r.arrow = 'fa fa-arrow-right fa-3x';

      }
    }


  }

  public divRegister(): void {
    this.divNumberBoolean = false;    
    this.divRegisterBoolean =true;

    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');
    let quotient: number = 0
    let remainder: number = 0;
    let remainderString: string = '';
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    quotient = Math.floor(temp3 / temp4);
    remainder = temp3 % temp4;

    //let temp6 = temp3 % temp4;
    temp3 = quotient;
    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;

    for (var i = 0; i < (16 - l); i++) {
      remainderString = remainderString + '0';
    }
    for (let r of this.register) {
      if (r.name == 'RAX') {
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = r.value;
      }
    }

    for (let r of this.register) {
      if (r.name == 'RDX') {
        remainderString = remainderString + remainder.toString(16);
        r.value = remainderString;
        r.arrow = 'fa fa-arrow-right fa-3x';
        this.remainderToDisplay = r.value;
      }
    }

    //this.outputValue = temp1.value;
  }

  public movNumber(): void {
    this.movNumberBoolean = true;    
    this.movRegisterBoolean =false;

    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        console.log(r.arrow);
      }
    }

  }

  public movRegister(): void {
     this.movNumberBoolean = false;    
    this.movRegisterBoolean =true;

    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x';
    this.outputValue = temp1.value;
  }

  public incNumber(): void {
  this.incBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        // let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 + 1;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        console.log(r.arrow);
      }
    }

  }
 
  public decNumber(): void {
  this.decBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        // let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - 1;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
        console.log(r.arrow);
      }
    }
  }

  public pushRegister() {
    let tempRSPValue: string;
    let temp: string;
    for(let sRegister of this.register){
              sRegister.arrow = '';
      if(this.selectedRegister1 == sRegister.name){
        temp = sRegister.value;
      }
    }
    for (let r = 0; r < this.register.length; r++) {
      if (this.register[r].name == 'RSP') {
        tempRSPValue = this.register[r].value;
        console.log(tempRSPValue);
        //console.log(this.memoryList.length);
      }
    }
    for (let r = 0; r < this.register.length; r++) {
      if (this.register[r].name == tempRSPValue) {
        for (let i = this.register.length - 1; i > r; i--) {

          this.register[i].value = this.register[i - 1].value;
        }
        this.register[r].value = temp;
        this.register[r].arrow = 'fa fa-arrow-right fa-3x';
      }
    }
  }

  public popRegister() {
    let tempRSPRegister : Register = new Register('','0','');
    let tempRSPValue: string;
    let temp: string;
    for (let r = 0; r < this.register.length; r++) {
      this.register[r].arrow = '';
      if (this.register[r].name == 'RSP') {
        tempRSPValue = this.register[r].value;
        console.log(tempRSPValue);
        tempRSPRegister =this.register[r];
        tempRSPRegister.arrow = 'fa fa-arrow-right fa-3x';
        //console.log(this.memoryList.length);
      }
    }
    for (let r = 0; r < this.register.length; r++) {
      if (this.register[r].name == tempRSPValue) {
        tempRSPRegister.value = this.register[r+1].name;
        for (let s of this.register) {
          if (this.selectedRegister1 == s.name) {
            s.value = this.register[r].value;
            s.arrow = 'fa fa-arrow-right fa-3x';
            

          }
        }

      }
    }
  }


  //    this.memoryList[j] = this.memoryList[j-1];

  //   }



  // -----------------------------------------------------------
  //   for(var i=0;i<this.memoryList.length; i++){
  //     console.log(this.memoryList.length);
  //     if(this.memoryList[i]!=tempRSPValue){
  //       continue; 
  //     }
  //     if(this.memoryList[i] == tempRSPValue){
  //       console.log('Inside if loop');
  //       this.pushRegister1(i);
  //     }
  //   }
  // }

  // public pushRegister1(i: number){
  //   console.log('inside pushRegister1 method');
  //   //let memoryIndexToInsert: number =i;
  //   for(let j =this.memoryList.length-1;j>i;j--){

  //    this.memoryList[j] = this.memoryList[j-1];

  //   }
  //   this.memoryList[i] = '5';
  //   console.log(this.memoryList[i]);
  // }




  public andNumber(): void {
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 & temp2;
        console.log(temp1);

        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
      }
    }

  }

  public andRegister(): void {
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 & temp4;
    console.log(temp3);
    //temp3 = temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x';
    this.outputValue = temp1.value;
  }


  public orNumber(): void {
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 | temp2;
        console.log(temp1);

        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
      }
    }
  }


  public orRegister(): void {
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 | temp4;
    console.log(temp3);
    //temp3 = temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x';
    this.outputValue = temp1.value;
  }


  public xorNumber(): void {
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 ^ temp2;
        console.log(temp1);

        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
      }
    }

  }

  public xorRegister(): void {
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 ^ temp4;
    console.log(temp3);
    //temp3 = temp4;

    let temp5 = temp3.toString(16);
    let l = temp5.length;
    let valueToStore: string = '';

    for (let i = 0; i < (16 - l); i++) {
      valueToStore = valueToStore + '0';
    }
    valueToStore += temp5;
    temp1.value = valueToStore;
    temp1.arrow = 'fa fa-arrow-right fa-3x';
    this.outputValue = temp1.value;
  }


  public notNumber(): void {
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        //let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = ~temp1;
        console.log(temp1);

        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        let l = temp3.length;
        let valueToStore: string = '';
        for (var i = 0; i < (16 - l); i++) {
          valueToStore = valueToStore + '0';
        }
        valueToStore = valueToStore + temp3;
        console.log(valueToStore);
        r.value = valueToStore;
        r.arrow = 'fa fa-arrow-right fa-3x';
      }
    }
  }

  public jmpLabel(): void {
     this.jmpRegisterBoolean = false;
    this.jmpNumberBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        r.arrow = 'fa fa-arrow-right fa-3x';
        console.log(r.arrow);
      }
    }
  }

  public cmpNumber(): void {
    this.cmpRegisterBoolean = false;
    this.cmpNumberBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        // let l = temp3.length;
        //  let valueToStore: string = '';
        // for (var i = 0; i < (16 - l); i++) {
        //   valueToStore = valueToStore + '0';
        // }
        // valueToStore = valueToStore + temp3;
        // console.log(valueToStore);
        // r.value = temp3;
        // r.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp3;
      }
    }

  }

  public cmpRegister(): void {
    this.cmpRegisterBoolean = true;
    this.cmpNumberBoolean = false;
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;

      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;

      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 - temp4;

    let temp5 = temp3.toString(16);
    // let l = temp5.length;
    // let valueToStore: string = '';

    // for (let i = 0; i < (16 - l); i++) {
    //   valueToStore = valueToStore + '0';
    // }
    // valueToStore += temp5;
    //temp1.value = valueToStore;
    // temp1.arrow = 'fa fa-arrow-right fa-3x'
    this.outputValue = temp5;
  }

  public jmpNumber(): void {
    this.jmpRegisterBoolean = false;
    this.jmpNumberBoolean = true;
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - temp2;
        //append zeros so that length becomes 16

        let temp3 = temp1.toString(16);

        // let l = temp3.length;
        //  let valueToStore: string = '';
        // for (var i = 0; i < (16 - l); i++) {
        //   valueToStore = valueToStore + '0';
        // }
        // valueToStore = valueToStore + temp3;
        // console.log(valueToStore);
        // r.value = temp3;
        // r.arrow = 'fa fa-arrow-right fa-3x';
        this.outputValue = temp3;
      }
    }

  }

  public jmpZeroNumber(): void {
    this.jmpZeroRegisterBoolean = false;
    this.jmpZeroNumberBoolean = true;
    
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - temp2;
        let temp3 = temp1.toString(16);
        this.outputValue = temp3;
      }
    }
        console.log(this.outputValue);
         for (let r of this.register) {
          if (this.outputValue == '0') {
            if (this.selectedRegister5 == r.name) {
              r.arrow = 'fa fa-arrow-right fa-3x';
              console.log("true");
             console.log(r.arrow);
            }            
          }
          else
          {
            r.arrow = '';
           console.log("False");
          }
          
         }                      
        
  }

  public jmpZeroRegister(): void {
    this.jmpZeroRegisterBoolean = true;
    this.jmpZeroNumberBoolean = false;
    
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;
      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;
      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 - temp4;
    let temp5 = temp3.toString(16);    
    this.outputValue = temp5;
        console.log(this.outputValue);
         for (let r of this.register) {
          if (this.outputValue == '0') {
            if (this.selectedRegister4 == r.name) {
              r.arrow = 'fa fa-arrow-right fa-3x';
              console.log("true");
             console.log(r.arrow);
            }            
          }
          else
          {
            r.arrow = '';
           console.log("False");
          }          
         }                      
        
  }

  public jmpIfNotZeroNumber(): void {
     this.jmpIfNotZeroRegisterBoolean = false;
    this.jmpIfNotZeroNumberBoolean = true;
    
    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister1 == r.name) {
        let temp1 = parseInt(r.value, 16);
        let temp2 = parseInt(this.valueToAdd, 16);
        temp1 = temp1 - temp2;
        let temp3 = temp1.toString(16);
        this.outputValue = temp3;
      }
    }
        console.log(this.outputValue);
         for (let r of this.register) {
          if (this.outputValue != '0') {
            if (this.selectedRegister5 == r.name) {
              r.arrow = 'fa fa-arrow-right fa-3x';
              console.log("false");
             console.log(r.arrow);
            }            
          }
          else 
          {
            r.arrow = '';
           console.log("true");
          }
          
         }    

  }

  public jmpIfNotZeroRegister(): void {
      this.jmpIfNotZeroRegisterBoolean = true;
    this.jmpIfNotZeroNumberBoolean = false;
    
    let temp1: Register = new Register('', '0', '');
    let temp2: Register = new Register('', '0', '');


    for (let r of this.register) {
      r.arrow = '';
      if (this.selectedRegister2 == r.name) {
        temp1 = r;
      }
    }
    for (let r of this.register) {
      if (this.selectedRegister3 == r.name) {
        temp2 = r;
      }
    }
    let temp3 = parseInt(temp1.value, 16);
    let temp4 = parseInt(temp2.value, 16);
    temp3 = temp3 - temp4;
    let temp5 = temp3.toString(16);    
    this.outputValue = temp5;
        console.log(this.outputValue);
         for (let r of this.register) {
          if (this.outputValue != '0') {
            if (this.selectedRegister4 == r.name) {
              r.arrow = 'fa fa-arrow-right fa-3x';
              console.log("false");
             console.log(r.arrow);
            }            
          }
          else
          {
            r.arrow = '';
           console.log("true");
          }          
         }      

  }


  public showAddSection() {
    this.resetParameters();
    this.showAdd = true;
  }

  public showSubSection() {
    this.resetParameters();
    this.showSub = true;
  }

  public showMulSection() {
    this.resetParameters();
    this.showMul = true;
  }


  public showDivSection() {
    this.resetParameters();
    this.showDiv = true;
  }

  public showMovSection() {
    this.resetParameters();
    this.showMov = true;
  }
  public showIncSection() {
    this.resetParameters();
    this.showInc = true;
  }
  public showDecSection() {
    this.resetParameters();
    this.showDec = true;
  }
  
  public showPushSection() {
    this.resetParameters();
    this.showPush = true;
  }
  public showPopSection() {
    this.resetParameters();
    this.showPop = true;
  }
  
  
  public showAndSection() {
    this.resetParameters();
    this.showAnd = true;
  }
  public showORSection() {
    this.resetParameters();
    this.showOR = true;
  }
  public showXORSection() {
    this.resetParameters();
    this.showXOR = true;
  }
  public showNOTSection() {
    this.resetParameters();
    this.showNOT = true;
  }
  public showJmpSection() {
    this.resetParameters();
    this.showJmp = true;
  }
    public showCmpSection() {
    this.resetParameters();
    this.showCmp = true;
  }

 public showJzSection() {
    this.resetParameters();
    this.showJz = true;
  }
 public showJnzSection() {
    this.resetParameters();
    this.showJnz = true;
  }




  //   public subRegister(): void {
  //   let temp1: Register = new Register('', '0');
  //   let temp2: Register = new Register('', '0');


  //   for (let r of this.register) {
  //     if (this.selectedRegister2 == r.name) {
  //       temp1 = r;

  //     }
  //   }
  //   for (let r of this.register) {
  //     if (this.selectedRegister3 == r.name) {
  //       temp2 = r;

  //     }
  //   }
  //   temp1.value = temp1.value - temp2.value;
  //   this.outputValue = temp1.value;
  // }
}