import { Component } from '@angular/core';
import { FormsModule, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'my-registers',
  templateUrl: './registers.html',
  styleUrls: ['./app.component.scss'],
})
export class Registers {
}