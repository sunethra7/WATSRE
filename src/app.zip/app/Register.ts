

export class Register {
  
    public name: string;
    public value: string;
    public arrow:string ='';
    constructor(s: string, n: string, a: string){
      this.name=s;
      this.value=n;
      this.arrow = a;
    }
    
}