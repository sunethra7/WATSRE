import { Component } from '@angular/core';

@Component({
  selector: 'my-help',
  templateUrl: './help.html',
  styleUrls: ['./app.component.scss'],
})
export class Help {}