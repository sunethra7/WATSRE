import { Component } from '@angular/core';
import { FormsModule, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'my-patterns',
  templateUrl: './findingPatterns.html',
  styleUrls: ['./app.component.scss'],
})
export class FindingPatterns {

  //

  private textAreaValue1: string = '';
  private outputValue : string = '';
  private outer : HTMLAnchorElement;
  private textAreaValue2: string = '';
  private finalLines = new Array();
  private outputLines = new Array;
  private outputLineLength =  0;
  public countSequences = 0;
  public disableFlag = false;
  private print2: any = "";
  private print3: any = "";
  private seqID: any = "";
  public seqID_1 = 0;
  public seqID_2 = 0;
  public seqID_3 = 0;
  private textSample : number;

  //*********************File uploading *********************** */

  changeListener($event: any): void {
    this.disableFlag = true;
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    var file: File = inputValue.files[0];
    var myReader: FileReader = new FileReader();
    var self = this;
    myReader.onloadend = function (e) {

      // you can perform an action with readed data here
      self.textAreaValue1 = myReader.result;
    }
    // waits(5000);

    // console.log(textFileData);
    console.dir(myReader);

    myReader.readAsText(file);
    console.log(file);
  }

  //*************************************************************** */

  //  Step 1: To count the number of instructions
  //  Imports: Instructions string Array
  //  updates the output value of results area


  countlines(lines: any[]) {
    var counter = 0;

    for (var i = 0; i < lines.length; i++) {
      if (lines[i] === "") {
        lines.splice(i, 1);
      } else {
        counter = counter + 1;
      }
    }
    console.log(counter);
    return counter.toString();


  }

  getFirstLineCounts() {
    var lines = new Array;
    lines = this.textAreaValue1.split('\n');
    console.log('lines 2 ' + this.countlines(lines));
    return this.countlines(lines);
  }

  updateResults() {
    //Populate ouputlines
    //write output value

    this.populateOutputLines();
    this.writeOutput();

  }

  populateOutputLines() {

    if (this.outputLineLength === 0) {
      this.outputLines[0] = 'Original Count: ' + this.getFirstLineCounts();
      this.outputLineLength = 1;
    }
    /* else if(this.outputLineLength === 1){
       this.outputLines[0] = 'Original Count: ' + this.getFirstLineCounts();
       this.outputLines[1] = 'Reduced Count: ' + this.countlines(this.finalLines);
       
       this.outputLineLength = 0;
       
       }*/

  }

  writeOutput() {
    var outputLength = this.outputLines.length;
    var outputString = '';
 
    if (outputLength === 1){
      this.outputValue = 'Original Count: ' +this.getFirstLineCounts() + 
      '\n'+ 'Reduced instruction Count:' +this.finalLines.length+ '\n'+
      'Number of sequences identified: '+ this.countSequences+'\n'+ 
      '****************************************'+'\n'+
      'Seq_ID_1 count -  '+this.seqID_1+'\n'+
      'Seq_ID_2 count -  '+this.seqID_2+'\n'+
      'Seq_ID_3 count -  '+this.seqID_3+'\n'+
      '***************************'+'\n'+
      'Sequences List:'+ '\n'+ this.print2+'\n';
      
      this.outer = this.print3;
      console.log(this.outer);
      console.log("___________________________________");
      console.log(this.print3);

            
    }
    else {
      for (var i = 0; i < outputLength; i++) {

        outputString = outputString + '\n' + this.outputLines[i] + '\n';
      }

      this.outputValue = outputString;
    }

  }

  updateResults1() {

    this.countlines(this.finalLines);

    for (var i = 0; i < this.finalLines.length; i++) {

      if (this.finalLines[i].includes('push')) {

        var pushString = this.getPatternForPush(i);


      }



    }

  }

  outputAreaPopulate() {
    var lines = this.textAreaValue1.split('\n');
    //console.log(lines);
    this.print2 = '';
    this.seqID_1 = 0;
    this.seqID_2 = 0;
    this.seqID_3 = 0;
    var newLines = this.unwantedInstructionsRemoval1(lines);

    this.finalLines = this.unwantedInstructionsRemoval2(newLines);  

    this.countSequences = 0;
    for (var i = 0; i<(this.finalLines.length-1); i++)
    {
      
      console.log('Final Lines' +this.finalLines.length);
      // Push Logic Starts here*******************************************************
      if(this.finalLines[i].instructions.trim().startsWith("push"))
      {
       // console.log(this.finalLines[i].instructions);
        if(this.finalLines[i+1].instructions.trim().startsWith("mov"))
        {          
          if(this.finalLines[i+2].instructions.trim().startsWith("sub"))
          {
            console.log("Variables are declared");
            this.countSequences++;
            this.seqID_1++;
            let printSeq3 = "{ - Start of the function with variables declared"
            this.print2 += 'Pattern: '+ this.countSequences+ '\n' + printSeq3+"\n"+ "In the line: " +(i+1)+ " " +(i+2)+ " "+(i+3) + this.finalLines[i].instructions+'\n'+this.finalLines[i+1].instructions+'\n'+this.finalLines[i+2].instructions+'\n';
            
          }

          else
          {
            console.log("{");
            this.countSequences++;
            this.seqID_2++;
            //let printSeq = "{"
            let printSeq = "{ - Start of the function"
            this.seqID = this.countSequences;
            this.print2 += 'Pattern: '+ this.countSequences + '\n'+ printSeq+"\n"+"In the line: "+ (i+1)+" " +(i+2)+ "\n" +this.finalLines[i].instructions+'\n'+this.finalLines[i+1].instructions+'\n';
            this.print3 += printSeq+"<\br>";
          }
        }
        else if(this.finalLines[i+1].instructions.trim().startsWith("call"))
        {
          if(this.finalLines[i+2].instructions.trim().startsWith("add"))
          {
            console.log("Prints to output and increments");
            this.countSequences++;
            this.seqID_3++;
            let printSeq2 = "Prints to output and increments"
            this.print2 += 'Pattern: '+ this.countSequences + '\n'+ printSeq2+'\n'+ (i+1)+" " +(i+2)+" "+(i+3) +this.finalLines[i].instructions+'\n'+this.finalLines[i+1].instructions+'\n'+this.finalLines[i+2].instructions+'\n';
            this.print3 += printSeq2+'<\br>';
            
          }

        }

      }
      // Push Logic Ends here*******************************************************

    }
    //Counting the number of patterns
    console.log(this.countSequences);
    this.outputValue = this.outputValue+"\n"+this.countSequences;

    //console.log(this.textAreaValue2);

   // console.log(this.finalLines[0].instructions);
    this.updateResults( );

  }

  getPatternForPush(lineIndex: number) {

    // If mov instruction comes after push '
    // then update the meaning of the console and 
    // update the number of such pair of instructions in output area

    // var json = { meaning: "", countInstructions: 0 };

    
    var consoleString;
    var patternNumber = 0;

    if (this.finalLines[lineIndex + 1].instructions.includes('mov')) {
      //Check if the sub follows
      if (this.finalLines[lineIndex + 2].instructions.includes('sub')) {
        //Pattern 4 of push detected, print 'Start of the function; Variables are declared and memory is allocated'
        
        var patternNumber = 4;

      }
      else {
        patternNumber = 1;
      }


    } else if (this.finalLines[lineIndex + 1].instructions.includes('call')) {

      //Check if add follows
      if (this.finalLines[lineIndex + 2].instructions.includes('add')) {
        //Pattern 4 of push detected, print 'Start of the function; Variables are declared and memory is allocated'

        var patternNumber = 2;

      }
      else {
        patternNumber = 3;
      }

    }
    
    switch (patternNumber) {
      case 1:
        consoleString = 'open brace {  start of the main function'

        break;

      case 2:
        consoleString = 'Prints Output';
        break;
      case 3:
        consoleString = 'Prints Output';
        break;
      case 4:
        consoleString = 'Start of the function; Variables are declared and memory is allocated';
        break;

      default:
        break;
    } {

    }






    return consoleString;

  }
  populateOutput() {

  }

  populateConsole(consoleString: string) {

  }

  unwantedInstructionsRemoval1(lines: string[]) {
    var outputString: string = '';
    var checkString: string = '';
    var i = 0;

    for (i = 0; i < lines.length; i++) {

      checkString = lines[i].toString();

      if (checkString.includes("nop") || checkString.includes("add byte ptr ds:[eax],al")) {
        lines.splice(i, 1);
        i--;
      }

    }

    return lines;

  }

  unwantedInstructionsRemoval2(lines: string[]) {

    var newLines = new Array;
    var i = 0;
    var outputString: string = '';
    var callLines = new Array;
    var retFlag = 0;
    var callString = "";
    var callAddress = "";
    var highestAddressCall = "";

    // Divide the lines into object array
    for (i = 0; i < lines.length; i++) {
      var json = { address: "", instructions: "" };
      json.address = lines[i].slice(0, 8);
      json.instructions = lines[i].slice(9, lines[i].length);
      newLines.push(json);
    }

    // clear object
    json = { address: "", instructions: "" };


    // Get all the call instructions before ret into another array
    for (i = 0; i < newLines.length; i++) {
      var newJson = { index: 0, address: "", instructions: "" };
      var inst = newLines[i].instructions;
      if (inst.includes("ret") && retFlag === 0) {
        retFlag = 1;

      }
      if (inst.includes("call") && retFlag === 0) {
        newJson.index = i;
        newJson.address = newLines[i].address;
        newJson.instructions = newLines[i].instructions;
        callLines.push(newJson);
      }

    }

    //  Find the highest call address
    for (i = 0; i < callLines.length; i++) {
      var spliceString = "";
      //callString = callLines[i].instructions.toString();
      //spliceString = callString.slice(callString.indexOf(".") + 1, callString.length);
      //callAddress = spliceString;
      callString = callLines[i].instructions.toString();
      spliceString = callString.slice(callString.indexOf(".") + 1, 6);
      //callAddress = parseInt(spliceString , 10);
      callAddress = spliceString;

      if (callAddress > highestAddressCall) {
        highestAddressCall = callAddress;
      }
    }

    highestAddressCall = callAddress;

    // output and remove all the lines until push C;
    for (i = 0; i < newLines.length; i++) {

      outputString =  outputString +((i+1)+" =>"+" "+ newLines[i].address) + " " + newLines[i].instructions + '\n';
      this.textAreaValue2 =  outputString;
      this.textSample = i;

      if (i > 0) {
        var instr = newLines[i].instructions;
        var previnstr = newLines[i - 1].instructions;
        var addres = newLines[i].address;
        if (addres.includes(highestAddressCall) && instr.includes("push C") && previnstr.includes("ret")) {
          newLines.splice(i + 1, newLines.length);
          break;
        }

      }
    }

    return newLines;


  }


}